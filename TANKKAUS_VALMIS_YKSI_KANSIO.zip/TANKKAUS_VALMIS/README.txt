TANKKAUS_APP – Sheets: auto + kuukausi omiin välilehtiin

Välilehtien nimi:
  "<AUTO> <YYYY-MM>"  esim: "GPG-830 2026-02"

Sovellus:
- Tallentaa jokaisen tankkauksen heti hyväksynnän jälkeen
- Historia näyttää valitun auton + valitun kuukauden (päivämääräkentän perusteella)

Kansiot:
1) tankkaus_app/
   - index.html + style.css + app.js (normaali)

2) tankkaus_app/singlefile/
   - index.html (CSS+JS upotettuna) -> paras Androidissa ilman serveriä

Apps Script:
- apps_script_Code.gs
  -> Liitä Google Apps Scriptiin (Code.gs) ja Deploy Web App (Anyone)
  -> Kopioi /exec URL sovelluksen ⚙️ Asetuksiin
